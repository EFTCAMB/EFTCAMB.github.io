Thanks for downloading EFTCAMB! This is EFTCAMB_Oct14, which is compatible with CAMB_Dec13. 

In order to build EFTCAMB, please follow these 6 steps:

1. Download CAMB version Dec13

2. Add these new files into your CAMB folder:
EFT_main.f90
equations_EFT.f90
EFTStabilitySpace.f90

3. Replace the default files with the following files:
cmbmain.f90
inidriver.F90
Makefile
Makefile_main
modules.f90
params.ini
subroutines.f90

4. configure the Makefile according to your Fortran compiler. We recommend "intel@Fortran Compilers-2013"

5. $make

6. $./camb params.ini

Besides the standard Boltzmann-solver, we also provide a new driver, namely "EFTStabilitySpace.f90", to study the stable EFT parameter regime,
such as figure 1. in our paper arXiv:1405.1022 [astro-ph.CO]. In order to do so, you have to do the following 2 steps:

1. Replace the EFTCAMB driver "DRIVER        ?= inidriver.F90" with 

# EFTCAMB: optional program to test stability.
DRIVER       ?= EFTstabilitySpace.f90

2. recompile and $./camb

After this, it will output "./Viable_Regions.dat" with three columns: "EFTparameter1, EFTparameter2, EFTStabilityResult ("1" for stable, "0" for unstable)"
You are encouraged to modify this file to investigate your relevant EFTparameters.

--
EFTCAMB team
Oct/2014

