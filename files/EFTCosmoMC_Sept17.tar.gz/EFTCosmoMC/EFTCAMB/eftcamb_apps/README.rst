=====================
EFTCAMB: applications
=====================

This folder contains the applications of the EFTCAMB code.

These will be automatically built by the Makefile by issuing::

   make eftcamb_apps

All the executables produced will be placed in the camb folder with suffix ``app_name.x``.