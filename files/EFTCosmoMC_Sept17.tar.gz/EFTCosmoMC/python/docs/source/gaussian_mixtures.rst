getdist.gaussian_mixtures
==================================



.. automodule:: getdist.gaussian_mixtures
   :members:


