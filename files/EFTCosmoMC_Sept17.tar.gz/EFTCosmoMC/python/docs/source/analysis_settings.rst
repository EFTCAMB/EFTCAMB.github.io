Analysis settings
==================================

Samples are analysed using various analysis settings. These can be specified from a .ini file or overridden using a dictionary.

Default settings from analysis_defaults.ini:

.. literalinclude:: ../../getdist/analysis_defaults.ini
   :language: ini