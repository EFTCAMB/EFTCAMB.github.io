getdist.inifile
==================================



.. automodule:: getdist.inifile
   :members:




   