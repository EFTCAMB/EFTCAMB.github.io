camb.model
==================================


.. autoclass:: camb.model.CAMBparams
   :members:
   :inherited-members:


.. autoclass:: camb.model.TransferParams
   :members:
   :inherited-members:


   