Thanks for downloading EFTCosmoMC! This is EFTCosmoMC_Oct14, which is compatible with CosmoMC_Dec13. 

In order to build EFTCosmoMC, please follow these 9 steps:

1. Download cosmomc version Dec13 (After extract: $mkdir ./plot_data)

2. Replace the default camb folder with the EFTCAMB one (see the readme of EFTCAMB)

3. In the root folder of cosmomc add:
EFT_params.ini

4. In the root folder of cosmomc replace the default files with:
params_CMB.paramnames

5. In the ./batch1 folder add:
common_batch1_EFT.ini
params_CMB_EFT.ini

6. In the ./source folder replace the default files with:
calclike.f90
CMB_Cls_simple.f90
cmbtypes.f90
driver.F90
Makefile
params_CMB.f90
settings.f90

7. configure the Makefile according to your Fortran and MPI compiler. We recommend "intel@Fortran Compilers-2013" and "Open MPI-1.6.4". 

8. $make all

9. $mpirun -np 8 ./cosmomc EFT_params.ini

--
EFTCAMB team
Oct/2014